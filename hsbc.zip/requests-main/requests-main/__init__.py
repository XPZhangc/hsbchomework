"""
Requests - HTTP库
一个优雅而简单的HTTP库，用于Python。
"""

__version__ = '2.31.0'
